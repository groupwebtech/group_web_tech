Deploy App On Hostinger
-----------------------

Now you can deploy apps directly from your Git repository. 
 
1. Create free hosting account on www.hostinger.com by choosing country nearest you.
1. Go to your hosting account cpanel. Find Git repositories section
1. Enter your repository URL and branch.
1. Click "Manage -> Deploy" to see your code go live.